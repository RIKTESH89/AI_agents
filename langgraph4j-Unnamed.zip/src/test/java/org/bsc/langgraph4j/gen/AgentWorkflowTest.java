package org.bsc.langgraph4j.gen;

import org.bsc.langgraph4j.CompileConfig;
import org.bsc.langgraph4j.RunnableConfig;
import org.bsc.langgraph4j.prebuilt.MessagesState;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.bsc.langgraph4j.StateGraph.END;
import static org.bsc.langgraph4j.action.AsyncEdgeAction.edge_async;
import static org.bsc.langgraph4j.action.AsyncNodeAction.node_async;

/**
* This is an automatically generated file.
*
* This file was generated using `langgraph4j-gen`.
*
* This file provides a placeholder implementation for the corresponding stub.
*
* Replace the placeholder implementation with your own logic.
*/
public class AgentWorkflowTest {

    @Test
    public void workflowTest() throws Exception {

        var graph = new AgentWorkflowBuilder<MessagesState<String>>()
            .orchestrator( node_async(state -> {
            System.out.println( "orchestrator" );
            return Map.of();
            }))
            .communication( node_async(state -> {
            System.out.println( "communication" );
            return Map.of();
            }))
            .scheduler( node_async(state -> {
            System.out.println( "scheduler" );
            return Map.of();
            }))
            .researcher( node_async(state -> {
            System.out.println( "researcher" );
            return Map.of();
            }))
            .Tool( node_async(state -> {
            System.out.println( "Tool" );
            return Map.of();
            }))
                .conditional_edge_1( edge_async( state -> {
                System.out.println( "conditional_edge_1" );
                // TODO: Returns one of the paths.
                return ;
                }))
                .conditional_edge_2( edge_async( state -> {
                System.out.println( "conditional_edge_2" );
                // TODO: Returns one of the paths.
                return ;
                }))
                .conditional_edge_3( edge_async( state -> {
                System.out.println( "conditional_edge_3" );
                // TODO: Returns one of the paths.
                return ;
                }))
        .build( MessagesState::new, MessagesState.SCHEMA );


        var compileConfig = CompileConfig.builder()
                            // Add persistence
                            // .checkpointSaver(new MemorySaver())
                            // add interruptions
                            // .interruptAfter( ... )  // Before nodes
                            // .interruptBefore( ) // After nodes
                            .build();

        var workflow = graph.compile( compileConfig );

        var runnableConfig = RunnableConfig.builder()
                            // add thread Id (i.e. execution session id )
                            // valid only if checkpointSaver is enabled (see above)
                            // .threadId( "my_thread" )
                            .build();

        var iterator = workflow.stream( Map.of(), runnableConfig );

        for( var out : iterator ) {
            System.out.println( out );
        }
    }
}