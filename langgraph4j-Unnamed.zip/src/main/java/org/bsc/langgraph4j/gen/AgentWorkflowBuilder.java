package org.bsc.langgraph4j.gen;

import org.bsc.langgraph4j.GraphStateException;
import org.bsc.langgraph4j.StateGraph;
import org.bsc.langgraph4j.action.AsyncEdgeAction;
import org.bsc.langgraph4j.action.AsyncNodeAction;
import org.bsc.langgraph4j.serializer.StateSerializer;
import org.bsc.langgraph4j.state.AgentState;
import org.bsc.langgraph4j.state.AgentStateFactory;
import org.bsc.langgraph4j.state.Channel;
import org.bsc.langgraph4j.utils.EdgeMappings;

import java.util.Map;
import java.util.Objects;

import static org.bsc.langgraph4j.StateGraph.START;
import static org.bsc.langgraph4j.StateGraph.END;

/**
 * This is an automatically generated file. Do not modify it.
 *
 * This file was generated using `langgraph4j-gen`.
 */
public class AgentWorkflowBuilder<State extends AgentState> {

    private AsyncNodeAction<State> orchestrator;
    private AsyncNodeAction<State> communication;
    private AsyncNodeAction<State> scheduler;
    private AsyncNodeAction<State> researcher;
    private AsyncNodeAction<State> Tool;
    private AsyncEdgeAction<State> conditional_edge_1;
    private AsyncEdgeAction<State> conditional_edge_2;
    private AsyncEdgeAction<State> conditional_edge_3;

        public AgentWorkflowBuilder<State> orchestrator(AsyncNodeAction<State> orchestrator) {
        this.orchestrator = orchestrator;
        return this;
        }
        public AgentWorkflowBuilder<State> communication(AsyncNodeAction<State> communication) {
        this.communication = communication;
        return this;
        }
        public AgentWorkflowBuilder<State> scheduler(AsyncNodeAction<State> scheduler) {
        this.scheduler = scheduler;
        return this;
        }
        public AgentWorkflowBuilder<State> researcher(AsyncNodeAction<State> researcher) {
        this.researcher = researcher;
        return this;
        }
        public AgentWorkflowBuilder<State> Tool(AsyncNodeAction<State> Tool) {
        this.Tool = Tool;
        return this;
        }

            public AgentWorkflowBuilder<State> conditional_edge_1(AsyncEdgeAction<State> conditional_edge_1) {
            this.conditional_edge_1 = conditional_edge_1;
            return this;
            }
            public AgentWorkflowBuilder<State> conditional_edge_2(AsyncEdgeAction<State> conditional_edge_2) {
            this.conditional_edge_2 = conditional_edge_2;
            return this;
            }
            public AgentWorkflowBuilder<State> conditional_edge_3(AsyncEdgeAction<State> conditional_edge_3) {
            this.conditional_edge_3 = conditional_edge_3;
            return this;
            }

    private StateGraph<State> of(AgentStateFactory<State> factory) {
        return new StateGraph<>( factory );
    }

    private StateGraph<State> of( StateSerializer<State> serializer) {
        return new StateGraph<>( serializer );
    }

    private StateGraph<State> of(Map<String, Channel<?>> channels, AgentStateFactory<State> factory) {
        return new StateGraph<>(factory);
    }

    private StateGraph<State> of(Map<String, Channel<?>> channels, StateSerializer<State> serializer) {
        return new StateGraph<>(serializer);
    }

    private StateGraph<State> build( StateGraph<State> graph ) throws GraphStateException {
            Objects.requireNonNull( orchestrator, "orchestrator cannot be null");
            Objects.requireNonNull( communication, "communication cannot be null");
            Objects.requireNonNull( scheduler, "scheduler cannot be null");
            Objects.requireNonNull( researcher, "researcher cannot be null");
            Objects.requireNonNull( Tool, "Tool cannot be null");
                Objects.requireNonNull( conditional_edge_1, "conditional_edge_1 cannot be null");
                Objects.requireNonNull( conditional_edge_2, "conditional_edge_2 cannot be null");
                Objects.requireNonNull( conditional_edge_3, "conditional_edge_3 cannot be null");

        return graph
            .addNode( "orchestrator", orchestrator )
            .addNode( "communication", communication )
            .addNode( "scheduler", scheduler )
            .addNode( "researcher", researcher )
            .addNode( "Tool", Tool )
                .addEdge( START, "orchestrator" )
                .addEdge( "Tool", "researcher" )
                .addEdge( "researcher", "Tool" )
                .addEdge( "communication", "Tool" )
                .addEdge( "Tool", "communication" )
                .addConditionalEdges( "orchestrator",
                conditional_edge_1,
                EdgeMappings.builder()
                    .to( "communication" )
                    .to( "scheduler" )
                    .to( "researcher" )
                .build())
                .addConditionalEdges( "scheduler",
                conditional_edge_2,
                EdgeMappings.builder()
                    .to( "Tool" )
                    .to( "communication" )
                .build())
                .addConditionalEdges( "Tool",
                conditional_edge_3,
                EdgeMappings.builder()
                    .to( "scheduler" )
                    .to( END )
                .build())
        ;

    }

    public StateGraph<State> build( AgentStateFactory<State> factory ) throws GraphStateException {
        return build( of( factory ) );
    }

    public StateGraph<State> build( StateSerializer<State> serializer ) throws GraphStateException {
        return build( of( serializer ) );
    }

    public StateGraph<State> build(AgentStateFactory<State> factory, Map<String, Channel<?>> channels ) throws GraphStateException {
        return build(of( channels, factory ));
    }

    public StateGraph<State> build(Map<String, Channel<?>> channels, StateSerializer<State> serializer) throws GraphStateException {
        return build(of( channels, serializer ));
    }

}