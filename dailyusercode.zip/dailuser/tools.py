"""
LangGraph-compatible tool functions for use in a StateGraph ToolNode.

These tools return structured JSON-like dicts with example data. Replace the stub
payloads with real data sources (database, APIs, local files) as needed.

Usage with LangGraph:

    from langgraph.prebuilt import ToolNode
    from tools import TOOLS

    tool_node = ToolNode(TOOLS)

Note: The @tool decorator is provided by langchain_core.tools and is fully
compatible with LangGraph's ToolNode.
"""
from __future__ import annotations

from typing import Any, Dict, List
import json
from pathlib import Path

try:
    # Preferred import for LangChain / LangGraph tool decorator
    from langchain_core.tools import tool as _lc_tool  # type: ignore
except Exception:  # pragma: no cover - fallback for older installs
    try:
        # Older versions may expose it under langchain.tools
        from langchain.tools import tool as _lc_tool  # type: ignore
    except Exception:
        # Minimal local fallback so this module works without LangChain installed.
        def _lc_tool(name_or_func=None):  # type: ignore
            """Local fallback decorator for @tool.

            Supports usage as @tool, @tool("name"), and @tool applied directly.
            Attaches .name and .description to the wrapped function.
            """
            def _decorate(func):
                tool_name = None
                if isinstance(name_or_func, str):
                    tool_name = name_or_func
                # Derive name
                setattr(func, "name", tool_name or getattr(func, "__name__", "tool"))
                # Derive description from docstring
                desc = getattr(func, "__doc__", "") or ""
                try:
                    desc = " ".join(desc.split())
                except Exception:
                    pass
                setattr(func, "description", desc)
                return func

            # If used as @tool without parentheses
            if callable(name_or_func):
                return _decorate(name_or_func)
            # If used as @tool() or @tool("name")
            return _decorate

# Public name for decorator
tool = _lc_tool


@tool("getProfile")
def getProfile() -> Dict[str, Any]:
    """Return a JSON object describing the user's profile.

    Includes: age, birth_date, gender, kind_of_person, hobbies, recent_interests.

    Returns:
        dict: Profile data. Replace with real data as needed.
    """
    # TODO: Replace stub with real data fetch (e.g., DB, API, or local file)
    return {
        "age": 29,
        "birth_date": "1996-03-14",
        "gender": "male",
        "kind_of_person": ["introvert", "analytical"],
        "hobbies": ["reading", "hiking", "photography"],
        "recent_interests": ["machine learning", "sourdough baking"],
    }


@tool("getCalendar")
def getCalendar() -> Dict[str, Any]:
    """Return a JSON object with the user's daily schedule.

    Example event format: 3:00 PM - 4:00 PM : "office annual review meeting".

    Returns:
        dict: Calendar data for a representative day.
    """
    # TODO: Wire to actual calendar source (Google Calendar, Outlook, etc.)
    return {
        "date": "2025-09-27",
        "events": [
            {
                "start": "03:00 PM",
                "end": "04:00 PM",
                "title": "office annual review meeting",
                "location": "HQ Conference Room B",
            },
            {
                "start": "08:00 PM",
                "end": "09:00 PM",
                "title": "society football match",
                "location": "Community Ground",
            },
        ],
    }


@tool("getFinance")
def getFinance() -> Dict[str, Any]:
    """Return a JSON object with the user's salary breakdown.

    Includes categories like savings, EMI, party, etc.

    Returns:
        dict: Finance breakdown data.
    """
    # TODO: Replace with secured finance data retrieval
    return {
        "currency": "INR",
        "salary_breakdown": {
            "savings": 30000,
            "emi": 12000,
            "rent": 15000,
            "party": 5000,
            "groceries": 6000,
            "utilities": 3500,
            "investments": 10000,
            "misc": 2500,
        },
    }


@tool("getContacts")
def getContacts() -> Dict[str, Any]:
    """Return a JSON object with the user's contact list.

    Contacts are grouped as office_mates, family, and friends.

    Returns:
        dict: Contacts data organized by category.
    """
    # TODO: Replace with real contact store (phonebook, CRM, etc.)
    return {
        "office_mates": [
            {
                "name": "Anita Sharma",
                "phone": "+91-98XXXXXX01",
                "email": "anita.sharma@example.com",
                "department": "Finance",
            },
            {
                "name": "Rahul Verma",
                "phone": "+91-98XXXXXX02",
                "email": "rahul.verma@example.com",
                "department": "Engineering",
            },
        ],
        "family": [
            {"name": "Suresh Kumar", "relation": "father", "phone": "+91-98XXXXXX11"},
            {"name": "Meera Kumari", "relation": "mother", "phone": "+91-98XXXXXX12"},
            {"name": "Aisha Kumar", "relation": "sister", "phone": "+91-98XXXXXX13"},
        ],
        "friends": [
            {"name": "Vikram Singh", "phone": "+91-98XXXXXX21"},
            {"name": "Neha Gupta", "phone": "+91-98XXXXXX22"},
            {"name": "Arjun Mehta", "phone": "+91-98XXXXXX23"},
        ],
    }


# Convenience export: list of tools to register with a ToolNode
TOOLS = [getProfile, getCalendar, getFinance, getContacts]

__all__ = [
    "getProfile",
    "getCalendar",
    "getFinance",
    "getContacts",
    "TOOLS",
]


@tool("list_tools")
def list_tools() -> List[Dict[str, str]]:
    """List all registered tools in this module with their names and descriptions.

    Returns:
        List[dict]: Each item has keys:
            - tool_name: The function name (decorator name) of the tool
            - tool_description: The docstring/description of the tool
    """
    # Use the TOOLS registry to determine which tools are exposed to LangGraph
    tools_list: List[Dict[str, str]] = []
    for t in TOOLS:
        # Decorator preserves __name__ and __doc__; additionally, langchain tools often set .name/.description
        name = getattr(t, "name", None) or getattr(t, "__name__", None) or "unknown"
        desc = getattr(t, "description", None) or getattr(t, "__doc__", None) or ""
        # Normalize docstring whitespace
        if isinstance(desc, str):
            desc = " ".join(desc.split())
        tools_list.append({
            "tool_name": str(name),
            "tool_description": str(desc),
        })
    return tools_list


@tool("list_agents")
def list_agents() -> List[Dict[str, Any]]:
    """List all available agents from agents.json with basic metadata.

    Reads agents.json colocated with this file and returns for each agent:
        - agent_id
        - agent_name
        - agent_description
        - base_system_prompt
        - required_tools (list[str])

    Returns:
        List[dict]: List of agent metadata objects.
    """
    try:
        base_dir = Path(__file__).resolve().parent
        agents_path = base_dir / "agents.json"
        data = json.loads(agents_path.read_text(encoding="utf-8"))
        result: List[Dict[str, str]] = []
        for a in data:
            result.append({
                "agent_id": str(a.get("agent_id", "")),
                "agent_name": str(a.get("agent_name", "")),
                "agent_description": str(a.get("agent_description", "")),
                "base_system_prompt": str(a.get("base_system_prompt", "")),
                "required_tools": list(a.get("required_tools", []) or []),
            })
        return result
    except FileNotFoundError:
        return [{
            "agent_id": "",
            "agent_name": "",
            "agent_description": "",
            "base_system_prompt": "",
            "error": "agents.json not found",
        }]
    except Exception as e:  # pragma: no cover - generic safety
        return [{
            "agent_id": "",
            "agent_name": "",
            "agent_description": "",
            "base_system_prompt": "",
            "error": f"Failed to read agents.json: {e}",
        }]


# Update tool registry to include new tools
TOOLS = [
    getProfile,
    getCalendar,
    getFinance,
    getContacts,
    list_tools,
    list_agents,
]

__all__.extend(["list_tools", "list_agents"])
