# Homeflow API

A tiny FastAPI service with a POST endpoint to append new scene objects to `homeflow.json`.

## Endpoints

- POST `/scenes`
  - Adds a new scene. Body must match the schema used in `homeflow.json` (see below).
- GET `/scenes`
  - Lists all scenes.
- GET `/scenes/{sceneId}`
  - Fetch a single scene by `sceneId`.
- DELETE `/scenes/{sceneId}`
  - Remove a scene by `sceneId`.

## JSON Schema (informal)

Top-level scene object fields:
- scene: string
- scene_description: string
- sceneId: string (unique)
- scene_name: string
- trigger_keywords: string[]
- experiences: Experience[]

Experience fields:
- experience_id: string
- experience_name: string
- experience_description: string
- uxTemplateId: string (e.g., UX-template-Form, UX-template-Research, UX-template-Communication)
- considerations: string[]
- user_input: {
  - prompt: string
  - fields?: { label: string; key: string; type: "text"|"number"|"date"|"time" }[]
}
- expected_output: { description: string }

## Run locally

1) Create a virtual environment and install deps

```powershell
python -m venv .venv
. .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2) Start the server (hot-reload)

```powershell
uvicorn app:app --host 127.0.0.1 --port 8000 --reload
```

Or simply:

```powershell
python app.py
```

3) Open docs

- Swagger UI: http://127.0.0.1:8000/docs
- OpenAPI JSON: http://127.0.0.1:8000/openapi.json

## Example request body for POST /scenes

```json
{
  "scene": "Example Planning",
  "scene_description": "Describe the purpose",
  "sceneId": "example_planning_main",
  "scene_name": "Plan example",
  "trigger_keywords": ["example", "sample"],
  "experiences": [
    {
      "experience_id": "first_step",
      "experience_name": "First step",
      "experience_description": "Do something",
      "uxTemplateId": "UX-template-Form",
      "considerations": ["Be concise"],
      "user_input": {
        "prompt": "Please provide details",
        "fields": [
          {"label": "Some text", "key": "some_text", "type": "text"},
          {"label": "A date", "key": "a_date", "type": "date"}
        ]
      },
      "expected_output": {"description": "What this produces"}
    }
  ]
}
```

Notes:
- `sceneId` must be unique; the API returns 409 if it already exists.
- File writes are serialized with a simple in-process lock and use a temp-file-and-replace strategy.
