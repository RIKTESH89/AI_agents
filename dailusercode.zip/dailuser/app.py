from __future__ import annotations

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional, Literal, Dict, Any
from pathlib import Path
import json
import threading


# Path to the JSON file that stores the homeflow list
HOMEFLOW_PATH = Path(__file__).with_name("homeflow.json")

# Simple in-process lock to serialize file writes
_file_lock = threading.Lock()


# ---------------
# Pydantic models
# ---------------


FieldType = Literal["text", "number", "date", "time"]


class FormField(BaseModel):
    label: str = Field(..., description="Human-friendly label for the input field")
    key: str = Field(..., min_length=1, description="Unique key used to store this input value")
    type: FieldType = Field(
        ..., description="Type of the input field (text, number, date, time)"
    )


class UserInput(BaseModel):
    prompt: str = Field(..., description="Prompt shown to the user for this step")
    # Optional for research/communication templates; required for some forms
    fields: Optional[List[FormField]] = Field(
        None,
        description="Optional form fields (typically present for UX-template-Form)",
    )


class ExpectedOutput(BaseModel):
    description: str = Field(
        ..., description="What the step should produce when completed"
    )


class Experience(BaseModel):
    experience_id: str = Field(..., min_length=1)
    experience_name: str
    experience_description: str
    uxTemplateId: str
    considerations: List[str]
    user_input: UserInput
    expected_output: ExpectedOutput


class Scene(BaseModel):
    scene: str
    scene_description: str
    sceneId: str = Field(..., min_length=1)
    scene_name: str
    trigger_keywords: List[str]
    experiences: List[Experience]


# -------------------
# Storage helpers
# -------------------


def _load_homeflow() -> List[dict]:
    if not HOMEFLOW_PATH.exists():
        return []
    try:
        with HOMEFLOW_PATH.open("r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
            raise ValueError("homeflow.json does not contain a JSON array")
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=500, detail=f"Invalid JSON in homeflow.json: {e}")


def _save_homeflow(data: List[dict]) -> None:
    # Persist with pretty formatting while preserving UTF-8 characters
    tmp_path = HOMEFLOW_PATH.with_suffix(".json.tmp")
    with tmp_path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
        f.write("\n")
    tmp_path.replace(HOMEFLOW_PATH)


# ---------------
# FastAPI app
# ---------------


app = FastAPI(title="Homeflow API", version="1.0.0")


@app.get("/scenes", response_model=List[Scene])
def list_scenes():
    """List all scenes currently stored in homeflow.json."""
    raw = _load_homeflow()
    # Validate against the model to ensure consistency on read
    return [Scene(**item) for item in raw]


@app.get("/scenes/{scene_id}", response_model=Scene)
def get_scene(scene_id: str):
    """Retrieve a specific scene by sceneId."""
    for item in _load_homeflow():
        if item.get("sceneId") == scene_id:
            return Scene(**item)
    raise HTTPException(status_code=404, detail=f"Scene with sceneId '{scene_id}' not found")


@app.post("/scenes", response_model=Scene, status_code=201)
def add_scene(scene: Scene):
    """
    Append a new scene object to homeflow.json.

    Requirements based on existing objects in the file:
    - Top-level fields required: scene, scene_description, sceneId, scene_name, trigger_keywords, experiences
    - Each experience requires: experience_id, experience_name, experience_description, uxTemplateId,
      considerations (list[str]), user_input (with prompt and optional fields[]), expected_output (with description)
    - For user_input.fields (when provided), each field has: label, key, type (text|number|date|time)
    """
    with _file_lock:
        data = _load_homeflow()

        # Enforce unique sceneId to keep list consistent
        if any(item.get("sceneId") == scene.sceneId for item in data):
            raise HTTPException(status_code=409, detail=f"sceneId '{scene.sceneId}' already exists")

        data.append(scene.model_dump())
        try:
            _save_homeflow(data)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to save: {e}")

    return scene


@app.delete("/scenes/{scene_id}", status_code=204)
def delete_scene(scene_id: str):
    """Delete a scene by sceneId (adjacent convenience endpoint)."""
    with _file_lock:
        data = _load_homeflow()
        new_data = [item for item in data if item.get("sceneId") != scene_id]
        if len(new_data) == len(data):
            raise HTTPException(status_code=404, detail=f"Scene with sceneId '{scene_id}' not found")
        _save_homeflow(new_data)
    return None


# -----------------------------
# Interpreter Agent Endpoint(s)
# -----------------------------


class InterpretRequest(BaseModel):
    prompt: str = Field(..., description="User prompt describing their intent")


class AgentPlanItem(BaseModel):
    sequence_no: int
    agent_id: str
    agent_prompt: str
    tools_required: List[str]


class InterpretResponse(BaseModel):
    matched_scene_id: Optional[str]
    matched_scene_name: Optional[str]
    matched_trigger_score: int
    plan: List[AgentPlanItem]


def _keyword_match_score(prompt: str, trigger_keywords: List[str]) -> int:
    """Compute a simple match score: count of trigger keywords present in prompt (case-insensitive).

    Args:
        prompt: input string
        trigger_keywords: list of keywords/phrases
    Returns:
        int: number of keywords found as substrings in the prompt
    """
    p = prompt.lower()
    score = 0
    for kw in trigger_keywords:
        if isinstance(kw, str) and kw.strip():
            if kw.lower() in p:
                score += 1
    return score


def _select_best_scene(prompt: str) -> Optional[Dict[str, Any]]:
    """Pick the scene with the highest keyword match score.

    If multiple have the same top score, pick the first. If all scores are 0, return None.
    """
    data = _load_homeflow()
    best = None
    best_score = 0
    for item in data:
        kws = item.get("trigger_keywords", []) or []
        score = _keyword_match_score(prompt, kws)
        if score > best_score:
            best = item
            best_score = score
    if best_score == 0:
        return None
    return best


@app.post("/interpret", response_model=InterpretResponse)
def interpret_prompt(body: InterpretRequest):
    """Interpreter route using a LangGraph pipeline to produce the plan response."""
    prompt = body.prompt.strip()
    if not prompt:
        raise HTTPException(status_code=400, detail="Prompt must not be empty")

    try:
        from interpreter import run_interpreter
        result = run_interpreter(prompt)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Interpreter failed: {e}")

    # Pydantic validation into our response model
    plan_items = []
    for i, item in enumerate(result.get("plan", []) or []):
        plan_items.append(
            AgentPlanItem(
                sequence_no=int(item.get("sequence_no", i + 1)),
                agent_id=str(item.get("agent_id", "")),
                agent_prompt=str(item.get("agent_prompt", "")),
                tools_required=[str(t) for t in (item.get("tools_required") or [])],
            )
        )

    return InterpretResponse(
        matched_scene_id=result.get("matched_scene_id"),
        matched_scene_name=result.get("matched_scene_name"),
        matched_trigger_score=int(result.get("matched_trigger_score", 0) or 0),
        plan=plan_items,
    )


if __name__ == "__main__":
    # Optional: run with `python app.py` for quick local testing without CLI
    import uvicorn

    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)
