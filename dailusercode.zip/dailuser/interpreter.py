from __future__ import annotations

from typing import Any, Dict, List, Optional, TypedDict
from pathlib import Path
import json

from langgraph.graph import StateGraph, END
import os
import re


class InterpState(TypedDict, total=False):
    prompt: str
    matched_scene: Optional[Dict[str, Any]]
    matched_score: int
    agents: List[Dict[str, Any]]
    tools: List[Dict[str, Any]]
    plan: List[Dict[str, Any]]


BASE_DIR = Path(__file__).resolve().parent
HOMEFLOW_PATH = BASE_DIR / "homeflow.json"


def _load_homeflow() -> List[Dict[str, Any]]:
    if not HOMEFLOW_PATH.exists():
        return []
    data = json.loads(HOMEFLOW_PATH.read_text(encoding="utf-8"))
    if isinstance(data, list):
        return data
    return []


def _keyword_match_score(prompt: str, trigger_keywords: List[str]) -> int:
    p = prompt.lower()
    score = 0
    for kw in trigger_keywords or []:
        if isinstance(kw, str) and kw.strip() and kw.lower() in p:
            score += 1
    return score


def _match_scene(state: InterpState) -> InterpState:
    prompt = state.get("prompt", "") or ""
    best = None
    best_score = 0
    for item in _load_homeflow():
        score = _keyword_match_score(prompt, item.get("trigger_keywords", []) or [])
        if score > best_score:
            best = item
            best_score = score
    state["matched_scene"] = best if best_score > 0 else None
    state["matched_score"] = best_score if best_score > 0 else 0
    return state


def _list_catalog(state: InterpState) -> InterpState:
    # We use the decorated tool functions directly; no LLM routing needed for this interpreter.
    from tools import list_agents as tool_list_agents
    from tools import list_tools as tool_list_tools

    state["agents"] = tool_list_agents()
    state["tools"] = tool_list_tools()
    return state


def _build_plan(state: InterpState) -> InterpState:
    tools = state.get("tools", []) or []
    agents = state.get("agents", []) or []
    matched = state.get("matched_scene") or {}
    available_tool_names = {str(t.get("tool_name")) for t in tools}

    plan: List[Dict[str, Any]] = []
    seq = 1
    for a in agents:
        agent_id = str(a.get("agent_id", ""))
        req = [str(x) for x in (a.get("required_tools") or [])]
        req = [t for t in req if t in available_tool_names]
        base_sp = str(a.get("base_system_prompt", "")).strip()
        # Compose a simple agent_prompt by combining the agent's base prompt with matched scene context
        scene_name = matched.get("scene_name") if matched else None
        scene_desc = matched.get("scene_description") if matched else None
        considerations = (matched.get("experiences") or [])
        # Flatten considerations across experiences
        cons_lines: List[str] = []
        for exp in considerations:
            for c in exp.get("considerations", []) or []:
                cons_lines.append(str(c))
        cons_text = "\n- ".join(cons_lines) if cons_lines else ""
        agent_prompt = base_sp or "You are an agent."
        agent_prompt += (
            f"\n\nContext: The user prompt is: {state.get('prompt','')}"
            + (f"\nMatched scene: {scene_name} - {scene_desc}" if scene_name else "")
            + (f"\nConsiderations:\n- {cons_text}" if cons_text else "")
        )
        plan.append({
            "sequence_no": seq,
            "agent_id": agent_id,
            "agent_prompt": agent_prompt,
            "tools_required": req,
        })
        seq += 1

    state["plan"] = plan
    return state


def run_interpreter(prompt: str) -> Dict[str, Any]:
    """Run the interpreter agent using a simple LangGraph pipeline.

    Returns a dict with keys:
        matched_scene_id, matched_scene_name, matched_trigger_score, plan
    """
    graph = StateGraph(InterpState)
    graph.add_node("match_scene", _match_scene)
    graph.add_node("list_catalog", _list_catalog)
    graph.add_node("build_plan", _build_plan)

    # Optional LLM-driven plan builder using Google Generative AI via LangChain
    def _llm_plan(state: InterpState) -> InterpState:
        # Only run if API key is available and package is installed
        api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GOOGLE_GENAI_API_KEY")
        if not api_key:
            return _build_plan(state)
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
        except Exception:
            return _build_plan(state)

        agents = state.get("agents", []) or []
        tools = state.get("tools", []) or []
        matched = state.get("matched_scene")
        available_tool_names = [str(t.get("tool_name")) for t in tools]

        # Prepare prompt for LLM
        sys_msg = (
            "You are an interpreter agent that plans which agents to run and in what order. "
            "You must ONLY select from the provided agents list and use ONLY tools that exist in the provided tools list. "
            "Build a concise plan reflecting the user's prompt and the matched scene, including a tailored system prompt per agent that instructs it exactly what to do. "
            "Output STRICT JSON: an array of objects with keys sequence_no (number), agent_id (string), agent_prompt (string), tools_required (array of strings). "
            "Do not include any prose before or after the JSON array."
        )
        # Include detailed scene data including experiences & considerations
        user_msg = {
            "prompt": prompt,
            "matched_scene": {
                "sceneId": matched.get("sceneId") if matched else None,
                "scene_name": matched.get("scene_name") if matched else None,
                "scene_description": matched.get("scene_description") if matched else None,
                "experiences": matched.get("experiences") if matched else None,
            },
            "agents": agents,
            "available_tools": available_tool_names,
            "instructions": [
                "Choose a relevant subset of agents (max 5) and order them logically. If none are relevant, return an empty JSON array []",
                "For each chosen agent, tools_required MUST be a subset of agent.required_tools AND available_tools",
                "If an agent has no required_tools or none are available, use an empty list []",
                "Construct agent_prompt as a SYSTEM PROMPT that: (1) restates the exact subtask for this agent, (2) references the matched scene name/description, (3) includes relevant 'considerations' from the scene's experiences, and (4) mirrors the agent's base_system_prompt tone/constraints if provided."
            ]
        }

        llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", temperature=0.2, api_key=api_key)
        try:
            resp = llm.invoke([
                ("system", sys_msg),
                ("human", json.dumps(user_msg, ensure_ascii=False)),
            ])
            text = getattr(resp, "content", None) or getattr(resp, "text", None) or ""
            # Extract JSON array
            match = re.search(r"\[.*\]", text, re.DOTALL)
            plan_json = match.group(0) if match else text
            plan_data = json.loads(plan_json)
            # Validate and normalize
            normalized: List[Dict[str, Any]] = []
            seq_seen = set()
            for i, item in enumerate(plan_data if isinstance(plan_data, list) else []):
                agent_id = str(item.get("agent_id", ""))
                if not agent_id or not any(a.get("agent_id") == agent_id for a in agents):
                    continue
                seq = int(item.get("sequence_no", i + 1))
                if seq in seq_seen:
                    seq = i + 1
                seq_seen.add(seq)
                req_tools = [str(t) for t in (item.get("tools_required") or [])]
                # Constrain to available tools
                req_tools = [t for t in req_tools if t in available_tool_names]
                # Constrain to the agent's declared required_tools, if provided
                agent_obj = next((a for a in agents if a.get("agent_id") == agent_id), None)
                agent_req = set([str(t) for t in (agent_obj.get("required_tools") or [])]) if agent_obj else set()
                if agent_req:
                    req_tools = [t for t in req_tools if t in agent_req]
                # Agent prompt
                agent_prompt = item.get("agent_prompt")
                if not isinstance(agent_prompt, str) or not agent_prompt.strip():
                    # fallback: synthesize from base_system_prompt and scene context
                    base_sp = str(agent_obj.get("base_system_prompt", "")) if agent_obj else ""
                    m = state.get("matched_scene") or {}
                    scene_name = m.get("scene_name")
                    scene_desc = m.get("scene_description")
                    agent_prompt = (base_sp or "You are an agent.") + (
                        f"\n\nContext: The user prompt is: {state.get('prompt','')}"
                        + (f"\nMatched scene: {scene_name} - {scene_desc}" if scene_name else "")
                    )
                normalized.append({
                    "sequence_no": seq,
                    "agent_id": agent_id,
                    "agent_prompt": agent_prompt,
                    "tools_required": req_tools,
                })
            state["plan"] = normalized
            return state
        except Exception:
            # Fallback to deterministic plan on any failure
            return _build_plan(state)

    graph.add_node("llm_plan", _llm_plan)

    graph.set_entry_point("match_scene")
    graph.add_edge("match_scene", "list_catalog")
    graph.add_edge("list_catalog", "llm_plan")
    graph.add_edge("llm_plan", END)

    app = graph.compile()
    final_state = app.invoke({"prompt": prompt})

    matched = final_state.get("matched_scene")
    matched_scene_id = matched.get("sceneId") if matched else None
    matched_scene_name = matched.get("scene_name") if matched else None
    matched_score = int(final_state.get("matched_score", 0) or 0)
    plan = final_state.get("plan", []) or []

    return {
        "matched_scene_id": matched_scene_id,
        "matched_scene_name": matched_scene_name,
        "matched_trigger_score": matched_score,
        "plan": plan,
    }
